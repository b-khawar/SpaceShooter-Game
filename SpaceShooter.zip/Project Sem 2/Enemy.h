#ifndef ENEMY_H
#define ENEMY_H

#include <iostream>
#include <SFML/Graphics.hpp>
using namespace std;
using namespace sf;


class Enemy{

public:
	Enemy(){ }
	
};

#endif
