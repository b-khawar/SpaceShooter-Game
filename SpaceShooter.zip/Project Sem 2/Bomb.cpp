#include "Bomb.h"

Bomb::Bomb(){
	tex.loadFromFile("img/enemy_laser.png");
	sprite.setTexture(tex);
}
